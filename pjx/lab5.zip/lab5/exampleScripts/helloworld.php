<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <title> HELLO World</title>
    </head>
    <body>
        <p>HTML says Hello world</p>
        <script type="text/javascript">
            document.write('<p>JavaScript says Hello World</p>')
        </script>
        <?php
        echo "<p>PHP says Hello World</p>"
        ?>
    </body>
</html>